#pragma once
#define MI_PRIMO "Hola M�n"


bool EscriurePrimo(int p);
