#pragma once
#define MI_FUNCIO "Hola M�n"


void EscriureFuncio(int n);
