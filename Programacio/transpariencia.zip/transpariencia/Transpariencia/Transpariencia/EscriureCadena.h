#pragma once
#define MI_CADENA "Hola M�n"

char Meva_CADENA[11] = { 'h','o','l','a',' ','r','o','b','e','r','t' };

void EscriureCadena(char Cadena[]);
